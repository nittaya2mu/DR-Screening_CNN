import cv2
import numpy as np
import csv
import matplotlib.pyplot as plt
import os

def find_color_as_white(image_path, color, showimage = False):

    img = cv2.imread(image_path)

    # Define the range for color in BGR
    if color == 'red':
        lower_color = np.array([0, 0, 100])
        upper_color = np.array([0, 0, 255])
    elif color == 'blue':
        lower_color = np.array([100, 0, 0])
        upper_color = np.array([255, 0, 0])
    elif color == 'green':
        lower_color = np.array([0, 100, 0])
        upper_color = np.array([0, 255, 0])
    elif color == 'yellow':
        lower_color = np.array([0, 100, 100])
        upper_color = np.array([100, 255, 255])

    # Create a mask for color
    mask = cv2.inRange(img, lower_color, upper_color)

    # Convert color areas to white in the binary image
    binary_image = mask.copy()
    binary_image[binary_image > 0] = 255

    # Display the binary image
    if showimage:
      plt.imshow(binary_image)
      plt.show()
    return binary_image


# Testing
binary_np = find_color_as_white('/content/annotation/TJDR_train_072.png','yellow', True)

#=========================================================
def get_areas(binary_np):
    # Find contours in the binary image
    contours, _ = cv2.findContours(binary_np, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    result = []
    for contour in contours:
        x, y, w, h = cv2.boundingRect(contour)
        area = w * h
        result.append((x, y, w, h))

    return result

# Testing
# bb_list = get_areas(binary_np)

#=========================================================
def draw_bounding_boxes(binary_np, bb_list, showimage = False):

    image_with_boxes = binary_np.copy()  # Create a copy to avoid modifying the original
    image_with_boxes = cv2.cvtColor(image_with_boxes, cv2.COLOR_GRAY2BGR)  # Convert to color for drawing

    for x, y, w, h in bb_list:
        cv2.rectangle(image_with_boxes, (x, y), (x + w, y + h), (255, 0, 255), 2)  # Draw rectangles
    if showimage:
      plt.imshow(image_with_boxes, cmap='gray')
      plt.show()
    return image_with_boxes

# Testing
# binary_np_with_bb = draw_bounding_boxes(binary_np, bb_list)
# cv2.imwrite('/content/annotation/output_image.jpg', binary_np_with_bb)

#=========================================================
def save_append_csv(csv_file, image_path, color, bb_list):
    with open(csv_file, 'a', newline='') as file:
        writer = csv.writer(file)

        # Check if the file is empty
        file.seek(0, 2)  # Move the file pointer to the end
        if file.tell() == 0:  # If file size is 0, it's empty
            writer.writerow(['filepath', 'color', 'x', 'y', 'w', 'h'])  # Add header

        # Assuming bb_list is a list of tuples (x, y, w, h)
        for x, y, w, h in bb_list:
            writer.writerow([image_path, color, x, y, w, h])

#=========================================================
def draw_bb_by_csv(csv_file, image_path, color):
  img = cv2.imread(image_path)
  with open(csv_file, 'r') as file:
    reader = csv.reader(file)
    next(reader)  # Skip header row
    for row in reader:
      file_image_path, file_color, x, y, w, h = row
      if file_image_path == image_path and file_color == color:
        x, y, w, h = int(x), int(y), int(w), int(h)
        cv2.rectangle(img, (x, y), (x + w, y + h), (255, 255, 255), 2)   # Draw rectangles
  if img is None:
    print("Image not found.")
    return None
  else :
    image = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    pixels = np.array(image)
    plt.imshow(pixels)
    plt.show()
  return img

#=========================================================

image_dir = '/content/annotation'
colors = ['red', 'blue', 'green', 'yellow']

os.remove('/content/annotation/annotation.csv')

for filename in os.listdir(image_dir):
  if filename.endswith('.jpg') or filename.endswith('.png'):  # Adjust file extensions as needed
    image_path = os.path.join(image_dir, filename)

    # Process the image (replace with your desired operations)
    for color in colors:
      binary_np = find_color_as_white(image_path, color)
      bb_list = get_areas(binary_np)
      binary_np_with_bb = draw_bounding_boxes(binary_np, bb_list)
      save_append_csv('/content/annotation/annotation.csv', image_path ,color, bb_list)

    # Save or display the processed image, etc.

csv_file = '/content/annotation/annotation.csv'
image_filename = '/content/annotation/TJDR_train_072.png'
color = 'green'
img = draw_bb_by_csv(csv_file, image_filename, color)
# if img is not None:
#   cv2.imwrite('/content/annotation/output_image.jpg', img)